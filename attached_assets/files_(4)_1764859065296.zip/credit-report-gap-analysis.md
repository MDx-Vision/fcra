# Credit Report Viewer - Gap Analysis & Correction Prompt

## CURRENT STATE (Screenshot Review)

**What's Working:**
- ✅ Credit scores display (615 / 528 / 625)
- ✅ Score labels (Fair/Poor/Fair)
- ✅ Dark UI layout looks good
- ✅ Report Summary box
- ✅ Trade Lines cards with status badges
- ✅ Recent Inquiries list with dates
- ✅ Creditor Contacts list

---

## CRITICAL GAPS IDENTIFIED

### 🔴 GAP 1: DATA ACCURACY ERRORS

**AFFIRM INC:**
- Current display: "Past due 90 days"
- Actual report: "Past due 60 days"
- **FIX: Parser is reading wrong value**

**APPLE CARD/GS BANK USA:**
- Current display: "No past due" (green)
- Actual report: "30 days past due" on Experian, "Past due 30 days" on TransUnion
- **FIX: This is WRONG - should be RED with "30 days past due"**

---

### 🔴 GAP 2: MISSING ACCOUNTS

**Current display:** 4 Trade Lines
**Actual report:** 15+ accounts

**Missing accounts:**
1. CAPITAL ONE (Authorized User) - $0 balance, $2,300 limit
2. NAVY FEDERAL CREDIT - $512 balance, $500 limit, Current
3. LEAD BANK - $704 balance, $925 limit, Current
4. SELF FINANCIAL/LEAD BA - Multiple accounts (installment + revolving)
5. KLARNA INC - 6 separate installment accounts
6. AMEX - 2 closed accounts (from 2015, closed 2021)
7. SYNCB/SMRTCN - Closed/Indeterminate (credit card lost/stolen)
8. GS BANK USA - Duplicate of Apple Card (same account, different name)

---

### 🔴 GAP 3: MISSING PERSONAL INFORMATION SECTION

**Not displayed at all:**
```
- Name per bureau (RAFAELAMIN vs RAFAEL vs RAFAELA - DISCREPANCY!)
- Also Known As variations
- Date of Birth (1972)
- Current Address: 600 W 161ST ST APT 4E, NEW YORK NY 10032
- Previous Addresses (Houston TX, Hasbrouck Heights NJ, etc.)
- Employer: THE NICEHR GROUP
```

**Should add section:**
```
┌─────────────────────────────────────────────────────────────┐
│ Personal Information                                        │
├─────────────────────────────────────────────────────────────┤
│ Name:                                                       │
│   TransUnion: RAFAELAMIN RODRIGUEZ                         │
│   Experian:   RAFAEL RODRIGUEZ                             │
│   Equifax:    RAFAELA RODRIGUEZ        ⚠️ DISCREPANCY      │
├─────────────────────────────────────────────────────────────┤
│ DOB: 1972                                                   │
│ Current Address: 600 W 161ST ST APT 4E, NEW YORK NY 10032  │
│ Employer: THE NICEHR GROUP                                  │
└─────────────────────────────────────────────────────────────┘
```

---

### 🔴 GAP 4: SUMMARY STATS INCOMPLETE

**Current display:** 
- 4 Total Accounts
- 3 Inquiries
- 0 Collections
- 0 Public Records

**Actual report per bureau:**

| Stat | TransUnion | Experian | Equifax |
|------|------------|----------|---------|
| Total Accounts | 10 | 15 | 7 |
| Open Accounts | 6 | 14 | 6 |
| Closed Accounts | 3 | 1 | 1 |
| Delinquent | 0 | 2 | 0 |
| Derogatory | 0 | 0 | 0 |
| Collections | 0 | 0 | 0 |
| Balances | $4,470 | $5,029 | $4,283 |
| Payments | $317 | $465 | $318 |
| Inquiries | 3 | 0 | 0 |

**FIX: Show per-bureau breakdown, not just one number**

---

### 🔴 GAP 5: TRADE LINE DETAIL MISSING

**Current card shows:**
- Creditor name
- Status badge

**Should show (at minimum on card):**
- Account number (masked): 130011XXXXXX
- Account type: Revolving / Installment
- Balance: $2,997
- Credit Limit: $3,000
- Date Opened: 08/01/2025
- Monthly Payment: $249

**On click/expand should show:**
- Full bureau comparison (3 columns)
- 24-month payment history grid
- All comments
- Creditor contact info

---

### 🔴 GAP 6: NO PAYMENT HISTORY DISPLAY

**Missing entirely:**
The 24-month payment history grid showing OK/30/60/90 per month per bureau

Example for APPLE CARD/GS BANK:
```
Month:  Nov  Oct  Sep  Aug  Jul  Jun  May  Apr  Mar
Year:   '25  '25  '25  '25  '25  '25  '25  '25  '25
TU:      -   60   OK   OK   -    -    -    -    -
EX:      -   30   OK   OK   -    -    -    -    -  
EQ:      -   OK   OK   -    -    -    -    -    -
```

---

### 🔴 GAP 7: NO DISCREPANCY DETECTION

**Not flagging:**
1. Name varies across bureaus (RAFAELAMIN vs RAFAEL vs RAFAELA)
2. Apple Card status differs (TU: 30 days, EX: 30 days, EQ: "not more than 2 payments")
3. Experian shows 2 delinquent, other bureaus show 0

---

### 🔴 GAP 8: SCORE FACTORS ALL N/A

**Current display:** All N/A for Score Factors section

**Should show (if available in report):**
- Account Type: Revolving/Installment mix
- Credit Limit: Total available
- Date Opened: Oldest account
- High Balance: Highest balance
- Monthly Payment: Total
- Past Due: Total past due
- Date Reported: Most recent

---

## CORRECTION PROMPT FOR REPLIT

```
## FIXES REQUIRED

### 1. FIX PARSER - Wrong Data Being Displayed

The parser is either:
a) Only reading one bureau (not all three)
b) Missing accounts entirely
c) Showing wrong payment status

VERIFY:
- AFFIRM INC should be "60 days past due" not "90 days"
- APPLE CARD/GS BANK should be "30 days past due" (RED) not "No past due" (GREEN)
- Should show 15+ accounts, not 4

### 2. ADD PERSONAL INFORMATION SECTION

Above Credit Scores, add:

```html
<div class="personal-info-section">
  <h3>Personal Information</h3>
  <div class="bureau-comparison">
    <div class="info-row">
      <label>Name:</label>
      <div class="bureau-values">
        <span class="tu">RAFAELAMIN RODRIGUEZ</span>
        <span class="ex">RAFAEL RODRIGUEZ</span>
        <span class="eq">RAFAELA RODRIGUEZ</span>
        <span class="discrepancy-badge">⚠️ Varies</span>
      </div>
    </div>
    <div class="info-row">
      <label>DOB:</label>
      <span>1972</span>
    </div>
    <div class="info-row">
      <label>Address:</label>
      <span>600 W 161ST ST APT 4E, NEW YORK NY 10032</span>
    </div>
    <div class="info-row">
      <label>Employer:</label>
      <span>THE NICEHR GROUP</span>
    </div>
  </div>
</div>
```

### 3. EXPAND SUMMARY STATS

Change from single values to per-bureau table:

```html
<div class="summary-table">
  <table>
    <thead>
      <tr>
        <th></th>
        <th>TransUnion</th>
        <th>Experian</th>
        <th>Equifax</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Total Accounts</td>
        <td>10</td>
        <td>15</td>
        <td>7</td>
      </tr>
      <tr>
        <td>Open</td>
        <td>6</td>
        <td>14</td>
        <td>6</td>
      </tr>
      <tr>
        <td>Delinquent</td>
        <td>0</td>
        <td class="highlight-red">2</td>
        <td>0</td>
      </tr>
      <tr>
        <td>Total Balance</td>
        <td>$4,470</td>
        <td>$5,029</td>
        <td>$4,283</td>
      </tr>
    </tbody>
  </table>
</div>
```

### 4. ENHANCE TRADE LINE CARDS

Each card should display:

```html
<div class="trade-line-card">
  <div class="card-header">
    <span class="creditor-name">APPLE CARD/GS BANK USA</span>
    <span class="status-badge red">30 Days Past Due</span>
  </div>
  <div class="card-body">
    <div class="detail-row">
      <span class="label">Account #:</span>
      <span class="value">130011XXXXXX</span>
    </div>
    <div class="detail-row">
      <span class="label">Type:</span>
      <span class="value">Revolving - Credit Card</span>
    </div>
    <div class="detail-row">
      <span class="label">Balance:</span>
      <span class="value">$2,997</span>
    </div>
    <div class="detail-row">
      <span class="label">Limit:</span>
      <span class="value">$3,000</span>
    </div>
    <div class="detail-row">
      <span class="label">Opened:</span>
      <span class="value">08/01/2025</span>
    </div>
    <div class="detail-row">
      <span class="label">Payment:</span>
      <span class="value">$249/mo</span>
    </div>
  </div>
  <div class="card-footer">
    <button class="view-details-btn">View Full Details</button>
  </div>
</div>
```

### 5. ADD PAYMENT HISTORY GRID (in detail view)

```html
<div class="payment-history">
  <h4>24-Month Payment History</h4>
  <table class="payment-grid">
    <thead>
      <tr>
        <th></th>
        <th>Nov'25</th>
        <th>Oct'25</th>
        <th>Sep'25</th>
        <th>Aug'25</th>
        <!-- ... more months -->
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>TransUnion</td>
        <td class="empty">-</td>
        <td class="late-60">60</td>
        <td class="ok">OK</td>
        <td class="ok">OK</td>
      </tr>
      <tr>
        <td>Experian</td>
        <td class="empty">-</td>
        <td class="late-30">30</td>
        <td class="ok">OK</td>
        <td class="ok">OK</td>
      </tr>
      <tr>
        <td>Equifax</td>
        <td class="empty">-</td>
        <td class="ok">OK</td>
        <td class="ok">OK</td>
        <td class="empty">-</td>
      </tr>
    </tbody>
  </table>
</div>
```

CSS for payment grid:
```css
.payment-grid .ok { background: #22c55e; color: white; }
.payment-grid .late-30 { background: #eab308; color: black; }
.payment-grid .late-60 { background: #f97316; color: white; }
.payment-grid .late-90 { background: #ef4444; color: white; }
.payment-grid .empty { background: #374151; color: #6b7280; }
```

### 6. ADD DISCREPANCY ALERTS

At top of report, show alert banner:

```html
<div class="discrepancy-alerts">
  <div class="alert alert-warning">
    <strong>⚠️ 3 Discrepancies Detected</strong>
    <ul>
      <li>Name spelled differently across bureaus</li>
      <li>APPLE CARD/GS BANK - Payment status varies between bureaus</li>
      <li>Experian reports 2 delinquent accounts, others report 0</li>
    </ul>
  </div>
</div>
```

### 7. COMPLETE ACCOUNT LIST

Ensure ALL accounts from report are parsed and displayed:

1. LEAD BANK - Revolving, $704, Current
2. CAPITAL ONE - Revolving, $0, Authorized User, Current
3. NAVY FEDERAL CREDIT - Revolving, $512, Current
4. APPLE CARD/GS BANK - Revolving, $2,997, 30 DAYS LATE
5. KOVO INC - Installment, $60, Current
6. KOVO INC - Revolving, $10, Current
7. SELF FINANCIAL/LEAD BA - Installment, $0, Closed
8. GS BANK USA - Revolving, $2,997 (may be duplicate of Apple Card)
9. NAVY FCU - Revolving, $512 (may be duplicate)
10. SELFINC/LEAD - Revolving, $891, Current
11. SELF/LEAD - Installment, $0, Closed
12. AMEX - Revolving, $0, Closed
13. AMEX - Open, $0, Closed
14. SYNCB/SMRTCN - Revolving, $0, Indeterminate
15. AFFIRM INC - Installment, $106, 60 DAYS LATE
16. KLARNA INC - Installment, $78, Current
17. KLARNA INC - Installment, $273, Current
18. KLARNA INC - Installment, $14, Current
19. KLARNA INC - Installment, $32, Current
20. KLARNA INC - Installment, $56, Current

Note: Some may be duplicates (same account reported by different bureaus with slightly different names). Parser should attempt to merge by account number.
```

---

## DATABASE CHECK

Verify these tables are being populated correctly:

```sql
-- Check how many accounts were parsed
SELECT COUNT(*) FROM accounts WHERE report_id = ?;
-- Should return 15+, not 4

-- Check for late payment accounts
SELECT creditor_name, tu_payment_status, ex_payment_status, eq_payment_status 
FROM accounts 
WHERE report_id = ?
AND (tu_payment_status LIKE '%past due%' 
     OR ex_payment_status LIKE '%past due%' 
     OR eq_payment_status LIKE '%past due%');

-- Check personal info was parsed
SELECT * FROM personal_info WHERE report_id = ?;
-- Should have 3 rows (one per bureau)

-- Check summary stats per bureau
SELECT * FROM summary_stats WHERE report_id = ?;
-- Should have 3 rows with different values
```

---

## PRIORITY ORDER

1. **P0 - CRITICAL:** Fix Apple Card showing wrong status (security/accuracy issue)
2. **P0 - CRITICAL:** Parse all accounts (15+, not just 4)
3. **P1 - HIGH:** Add Personal Information section with discrepancy flag
4. **P1 - HIGH:** Expand Summary Stats to per-bureau table
5. **P2 - MEDIUM:** Add detail to Trade Line cards (balance, limit, opened date)
6. **P2 - MEDIUM:** Add payment history grid on detail view
7. **P3 - LOW:** Populate Score Factors if data available
