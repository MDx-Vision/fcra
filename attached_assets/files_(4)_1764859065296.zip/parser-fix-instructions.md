# PDF Parser Fix - Correction Instructions

## THE PROBLEM

Your current `services/pdf_parser_service.py` is designed for **single-bureau reports** but Rafael's report is a **THREE-BUREAU report** (TransUnion, Experian, Equifax side-by-side).

### Current Parser Issues:

1. **Detects ONE bureau** - But report has ALL THREE
2. **Extracts single values** - Should extract `tu_balance`, `ex_balance`, `eq_balance`
3. **Generic regex patterns** - Don't match the three-column table format
4. **Missing payment history grid** - The OK/30/60/90 month grid isn't parsed
5. **No per-bureau personal info** - Misses name variations (RAFAELAMIN vs RAFAEL vs RAFAELA)

### Result:
- Only 4 accounts detected instead of 15+
- Apple Card shows "No past due" when it's actually 30 days late
- Affirm shows 90 days when it's 60 days
- No discrepancy detection

---

## THE FIX

### Step 1: Replace the Parser

Replace `services/pdf_parser_service.py` with the new `three_bureau_parser.py` I've provided.

```bash
# Backup old parser
cp services/pdf_parser_service.py services/pdf_parser_service.py.backup

# Copy new parser
cp three_bureau_parser.py services/pdf_parser_service.py
```

### Step 2: Update Your Data Model

The new parser returns a different structure. Update your models/database:

**OLD structure (single bureau):**
```python
{
    "bureau": "Experian",
    "accounts": [
        {"name": "APPLE CARD", "balance": 2997, "status": "Open"}
    ]
}
```

**NEW structure (three bureau):**
```python
{
    "report_type": "three_bureau",
    "credit_scores": {
        "transunion": {"score": 615, "rank": "Fair"},
        "experian": {"score": 528, "rank": "Poor"},
        "equifax": {"score": 625, "rank": "Fair"}
    },
    "accounts": [
        {
            "creditor_name": "APPLE CARD/GS BANK",
            "tu_balance": 2997.00,
            "ex_balance": 2997.00,
            "eq_balance": 2997.00,
            "tu_payment_status": "30 days past due",
            "ex_payment_status": "Past due 30 days",
            "eq_payment_status": "Not more than two payments past due",
            "has_derogatory": True,
            "payment_history": [
                {"month": "Oct", "year": "2025", "tu_status": "60", "ex_status": "30", "eq_status": "OK"}
            ]
        }
    ],
    "discrepancies": [
        {"type": "personal_info", "field": "name", "description": "Name varies across bureaus"}
    ],
    "derogatory_accounts": [
        {"creditor_name": "APPLE CARD/GS BANK", "issues": [{"bureau": "Experian", "issue": "30 days past due"}]}
    ]
}
```

### Step 3: Update Your Views/Templates

Your display code needs to handle per-bureau data:

**Trade Line Card - BEFORE:**
```html
<div class="trade-line">
    <h4>{{ account.name }}</h4>
    <span class="badge {{ account.status }}">{{ account.status }}</span>
</div>
```

**Trade Line Card - AFTER:**
```html
<div class="trade-line">
    <h4>{{ account.creditor_name }}</h4>
    
    <!-- Show worst status across bureaus -->
    {% set worst_status = get_worst_status(account) %}
    <span class="badge {{ worst_status.class }}">{{ worst_status.text }}</span>
    
    <!-- Show balance (usually same across bureaus) -->
    <p>Balance: ${{ account.tu_balance or account.ex_balance or account.eq_balance }}</p>
    
    <!-- Show if there's a discrepancy -->
    {% if account.has_discrepancy %}
    <span class="discrepancy-badge">⚠️ Discrepancy</span>
    {% endif %}
</div>
```

### Step 4: Add Helper Function for Worst Status

```python
def get_worst_payment_status(account):
    """Get the worst payment status across all bureaus."""
    statuses = [
        account.get("tu_payment_status", ""),
        account.get("ex_payment_status", ""),
        account.get("eq_payment_status", "")
    ]
    
    # Priority: 90+ > 60 > 30 > Current
    for status in statuses:
        if not status:
            continue
        status_lower = status.lower()
        if "90" in status_lower or "charge" in status_lower:
            return {"text": "90+ Days Past Due", "class": "badge-danger", "level": 4}
        if "60" in status_lower:
            return {"text": "60 Days Past Due", "class": "badge-danger", "level": 3}
        if "30" in status_lower:
            return {"text": "30 Days Past Due", "class": "badge-warning", "level": 2}
    
    # Check if any status indicates current/good
    for status in statuses:
        if status and ("current" in status.lower() or "agreed" in status.lower() or "pays" in status.lower()):
            return {"text": "Current", "class": "badge-success", "level": 0}
    
    return {"text": "Unknown", "class": "badge-secondary", "level": -1}
```

---

## DATABASE SCHEMA UPDATE

If using SQLite, update your schema:

```sql
-- Drop old accounts table
ALTER TABLE accounts RENAME TO accounts_old;

-- Create new accounts table with per-bureau columns
CREATE TABLE accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER REFERENCES credit_reports(id),
    creditor_name TEXT NOT NULL,
    account_number TEXT,
    account_type TEXT,
    account_type_detail TEXT,
    
    -- TransUnion
    tu_status TEXT,
    tu_balance DECIMAL(12,2),
    tu_credit_limit DECIMAL(12,2),
    tu_high_credit DECIMAL(12,2),
    tu_monthly_payment DECIMAL(10,2),
    tu_date_opened TEXT,
    tu_payment_status TEXT,
    tu_last_reported TEXT,
    tu_past_due DECIMAL(12,2),
    tu_bureau_code TEXT,
    
    -- Experian
    ex_status TEXT,
    ex_balance DECIMAL(12,2),
    ex_credit_limit DECIMAL(12,2),
    ex_high_credit DECIMAL(12,2),
    ex_monthly_payment DECIMAL(10,2),
    ex_date_opened TEXT,
    ex_payment_status TEXT,
    ex_last_reported TEXT,
    ex_past_due DECIMAL(12,2),
    ex_bureau_code TEXT,
    
    -- Equifax
    eq_status TEXT,
    eq_balance DECIMAL(12,2),
    eq_credit_limit DECIMAL(12,2),
    eq_high_credit DECIMAL(12,2),
    eq_monthly_payment DECIMAL(10,2),
    eq_date_opened TEXT,
    eq_payment_status TEXT,
    eq_last_reported TEXT,
    eq_past_due DECIMAL(12,2),
    eq_bureau_code TEXT,
    
    -- Flags
    has_discrepancy BOOLEAN DEFAULT FALSE,
    has_derogatory BOOLEAN DEFAULT FALSE,
    discrepancy_notes TEXT,
    derogatory_notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Payment history table (per month, per bureau)
CREATE TABLE payment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER REFERENCES accounts(id),
    month TEXT,
    year TEXT,
    tu_status TEXT,
    ex_status TEXT,
    eq_status TEXT
);

-- Discrepancies table
CREATE TABLE discrepancies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER REFERENCES credit_reports(id),
    account_id INTEGER REFERENCES accounts(id),
    type TEXT,
    field TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## TESTING THE FIX

After replacing the parser, test with Rafael's report:

```python
from services.pdf_parser_service import parse_credit_report_pdf

result = parse_credit_report_pdf("/path/to/RRodriguez11_17_20_25.pdf")

# Should now see:
print(f"Accounts found: {len(result['accounts'])}")  # Should be 15+, not 4
print(f"Discrepancies: {len(result['discrepancies'])}")  # Should find name discrepancy
print(f"Derogatory: {len(result['derogatory_accounts'])}")  # Should find Apple Card, Affirm

# Check Apple Card specifically
for acct in result['accounts']:
    if 'APPLE' in acct.get('creditor_name', '').upper():
        print(f"Apple Card - TU Status: {acct.get('tu_payment_status')}")
        print(f"Apple Card - EX Status: {acct.get('ex_payment_status')}")
        print(f"Apple Card - EQ Status: {acct.get('eq_payment_status')}")
        # Should show "30 days past due" or similar, NOT "Current"
```

---

## QUICK DEBUG

If the parser still isn't working, check what text is being extracted:

```python
from services.pdf_parser_service import extract_text_from_pdf

text, error = extract_text_from_pdf("/path/to/RRodriguez11_17_20_25.pdf")

# Save to file to inspect
with open("debug_extracted_text.txt", "w") as f:
    f.write(text)

# Look for these strings in the output:
# - "APPLE CARD" 
# - "30 days past due"
# - "TransUnion | Experian | Equifax" (column headers)
```

If the text doesn't contain table structures properly, the PDF might need OCR processing instead of text extraction.

---

## FILES PROVIDED

1. `three_bureau_parser.py` - New parser to replace `services/pdf_parser_service.py`
2. `credit-report-gap-analysis.md` - Full gap analysis of what's missing
3. This file - Instructions for implementing the fix

Let me know if you need help with any specific part of the implementation!
