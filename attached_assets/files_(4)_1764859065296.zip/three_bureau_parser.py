"""
Three-Bureau Credit Report Parser Service
Parses combined TransUnion/Experian/Equifax credit reports from services like IdentityIQ, SmartCredit, etc.

This parser is specifically designed for reports that show all three bureaus side-by-side.
"""
import os
import re
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from decimal import Decimal

logger = logging.getLogger(__name__)


# =============================================================================
# TEXT EXTRACTION
# =============================================================================

def extract_text_from_pdf(file_path: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Extract text from PDF using pdfplumber (best for tables).
    Returns (text, error_message).
    """
    if not os.path.exists(file_path):
        return None, f"File not found: {file_path}"
    
    try:
        import pdfplumber
        text_parts = []
        tables_data = []
        
        with pdfplumber.open(file_path) as pdf:
            for page_num, page in enumerate(pdf.pages):
                # Extract regular text
                text = page.extract_text()
                if text:
                    text_parts.append(f"=== PAGE {page_num + 1} ===\n{text}")
                
                # Extract tables separately (crucial for three-bureau format)
                tables = page.extract_tables()
                for table_idx, table in enumerate(tables):
                    if table:
                        table_text = f"\n=== TABLE {page_num + 1}.{table_idx + 1} ===\n"
                        for row in table:
                            if row:
                                # Join cells with pipe delimiter
                                row_text = " | ".join([str(cell).strip() if cell else "" for cell in row])
                                table_text += row_text + "\n"
                        tables_data.append(table_text)
        
        # Combine text and tables
        full_text = "\n\n".join(text_parts)
        if tables_data:
            full_text += "\n\n=== EXTRACTED TABLES ===\n" + "\n".join(tables_data)
        
        if full_text and len(full_text.strip()) > 100:
            logger.info(f"Extracted {len(full_text)} chars using pdfplumber")
            return full_text, None
        
        return None, "Could not extract sufficient text from PDF."
        
    except ImportError:
        return None, "pdfplumber not installed. Run: pip install pdfplumber"
    except Exception as e:
        logger.error(f"PDF extraction failed: {e}")
        return None, f"PDF extraction error: {str(e)}"


# =============================================================================
# THREE-BUREAU SPECIFIC PARSING
# =============================================================================

def parse_three_bureau_report(file_path: str) -> Dict[str, Any]:
    """
    Parse a three-bureau credit report (TransUnion, Experian, Equifax combined).
    
    This handles reports from services like:
    - IdentityIQ
    - SmartCredit
    - MyScoreIQ
    - PrivacyGuard
    """
    result = {
        "success": False,
        "error": None,
        "report_type": "three_bureau",
        "reference_number": None,
        "report_date": None,
        
        # Personal info per bureau
        "personal_info": {
            "transunion": {},
            "experian": {},
            "equifax": {}
        },
        
        # Scores per bureau
        "credit_scores": {
            "transunion": {"score": None, "rank": None},
            "experian": {"score": None, "rank": None},
            "equifax": {"score": None, "rank": None}
        },
        
        # Summary stats per bureau
        "summary_stats": {
            "transunion": {},
            "experian": {},
            "equifax": {}
        },
        
        # Accounts with per-bureau data
        "accounts": [],
        
        # Inquiries
        "inquiries": [],
        
        # Public records
        "public_records": [],
        
        # Creditor contacts
        "creditor_contacts": [],
        
        # Analysis flags
        "discrepancies": [],
        "derogatory_accounts": [],
        
        "raw_text": None,
        "parsing_confidence": 0.0
    }
    
    # Extract text
    text, error = extract_text_from_pdf(file_path)
    if error:
        result["error"] = error
        return result
    
    result["raw_text"] = text
    
    # Parse each section
    result["reference_number"] = extract_reference_number(text)
    result["report_date"] = extract_report_date(text)
    result["personal_info"] = extract_personal_info_three_bureau(text)
    result["credit_scores"] = extract_credit_scores(text)
    result["summary_stats"] = extract_summary_stats(text)
    result["accounts"] = extract_accounts_three_bureau(text)
    result["inquiries"] = extract_inquiries_three_bureau(text)
    result["public_records"] = extract_public_records(text)
    result["creditor_contacts"] = extract_creditor_contacts(text)
    
    # Run discrepancy detection
    result["discrepancies"] = detect_discrepancies(result)
    result["derogatory_accounts"] = detect_derogatory_accounts(result["accounts"])
    
    # Calculate confidence
    result["parsing_confidence"] = calculate_confidence(result)
    result["success"] = True
    
    logger.info(f"Parsed three-bureau report: {len(result['accounts'])} accounts, "
                f"{len(result['discrepancies'])} discrepancies, "
                f"{len(result['derogatory_accounts'])} derogatory")
    
    return result


def extract_reference_number(text: str) -> Optional[str]:
    """Extract report reference number."""
    patterns = [
        r"Reference\s*#?\s*:?\s*([A-Z0-9]+)",
        r"Report\s*(?:ID|Number|#)\s*:?\s*([A-Z0-9]+)",
        r"Confirmation\s*#?\s*:?\s*([A-Z0-9]+)"
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def extract_report_date(text: str) -> Optional[str]:
    """Extract report date."""
    patterns = [
        r"Report\s*Date\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})",
        r"Credit\s*Report\s*Date\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})",
        r"Generated\s*:?\s*(\d{1,2}/\d{1,2}/\d{4})"
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def extract_personal_info_three_bureau(text: str) -> Dict[str, Dict]:
    """Extract personal information per bureau."""
    info = {
        "transunion": {"name": None, "also_known_as": None, "dob": None, "address": None, "employer": None},
        "experian": {"name": None, "also_known_as": None, "dob": None, "address": None, "employer": None},
        "equifax": {"name": None, "also_known_as": None, "dob": None, "address": None, "employer": None}
    }
    
    # Look for the Personal Information section
    personal_section = extract_section(text, "Personal Information", ["Credit Score", "Summary", "Account History"])
    if not personal_section:
        return info
    
    # Pattern for three-column personal info table
    # Format: Field | TransUnion Value | Experian Value | Equifax Value
    
    # Name row
    name_match = re.search(
        r"Name\s*:?\s*\|?\s*([A-Z][A-Z\s,]+?)\s*\|?\s*([A-Z][A-Z\s,]+?)\s*\|?\s*([A-Z][A-Z\s,]+?)(?:\n|$)",
        personal_section, re.IGNORECASE
    )
    if name_match:
        info["transunion"]["name"] = clean_name(name_match.group(1))
        info["experian"]["name"] = clean_name(name_match.group(2))
        info["equifax"]["name"] = clean_name(name_match.group(3))
    
    # Also look for patterns like "RAFAELAMIN RODRIGUEZ" followed by other bureau names
    # The report shows names in a table format
    name_patterns = [
        r"RAFAEL\s*A?MIN\s*RODRIGUEZ",
        r"RAFAEL\s*H?\s*RODRIGUEZ", 
        r"RAFAELA?\s*RODRIGUEZ"
    ]
    
    # DOB row
    dob_match = re.search(
        r"(?:Date of Birth|DOB)\s*:?\s*\|?\s*(\d{4})\s*\|?\s*(\d{4})\s*\|?\s*(\d{4})",
        personal_section, re.IGNORECASE
    )
    if dob_match:
        info["transunion"]["dob"] = dob_match.group(1)
        info["experian"]["dob"] = dob_match.group(2)
        info["equifax"]["dob"] = dob_match.group(3)
    
    # Employer row
    employer_match = re.search(
        r"Employer[s]?\s*:?\s*\|?\s*([A-Z][A-Z\s]+?)\s*\|?\s*(NA|[A-Z][A-Z\s]+?)\s*\|?\s*(NA|[A-Z][A-Z\s]+?)(?:\n|$)",
        personal_section, re.IGNORECASE
    )
    if employer_match:
        info["transunion"]["employer"] = employer_match.group(1).strip() if employer_match.group(1) != "NA" else None
        info["experian"]["employer"] = employer_match.group(2).strip() if employer_match.group(2) != "NA" else None
        info["equifax"]["employer"] = employer_match.group(3).strip() if employer_match.group(3) != "NA" else None
    
    return info


def extract_credit_scores(text: str) -> Dict[str, Dict]:
    """Extract credit scores per bureau."""
    scores = {
        "transunion": {"score": None, "rank": None},
        "experian": {"score": None, "rank": None},
        "equifax": {"score": None, "rank": None}
    }
    
    # Look for Credit Score section
    score_section = extract_section(text, "Credit Score", ["Summary", "Account History", "Trade Lines"])
    if not score_section:
        score_section = text
    
    # TransUnion score
    tu_match = re.search(r"TransUnion[:\s]*(\d{3})", score_section, re.IGNORECASE)
    if tu_match:
        scores["transunion"]["score"] = int(tu_match.group(1))
    
    # Experian score
    ex_match = re.search(r"Experian[:\s]*(\d{3})", score_section, re.IGNORECASE)
    if ex_match:
        scores["experian"]["score"] = int(ex_match.group(1))
    
    # Equifax score
    eq_match = re.search(r"Equifax[:\s]*(\d{3})", score_section, re.IGNORECASE)
    if eq_match:
        scores["equifax"]["score"] = int(eq_match.group(1))
    
    # Alternative: Look for three scores in a row
    three_scores = re.search(r"(\d{3})\s+(\d{3})\s+(\d{3})", score_section)
    if three_scores and not scores["transunion"]["score"]:
        scores["transunion"]["score"] = int(three_scores.group(1))
        scores["experian"]["score"] = int(three_scores.group(2))
        scores["equifax"]["score"] = int(three_scores.group(3))
    
    # Determine rank based on score
    for bureau in scores:
        score = scores[bureau]["score"]
        if score:
            if score >= 750:
                scores[bureau]["rank"] = "Excellent"
            elif score >= 700:
                scores[bureau]["rank"] = "Good"
            elif score >= 650:
                scores[bureau]["rank"] = "Fair"
            elif score >= 550:
                scores[bureau]["rank"] = "Poor"
            else:
                scores[bureau]["rank"] = "Very Poor"
    
    return scores


def extract_summary_stats(text: str) -> Dict[str, Dict]:
    """Extract summary statistics per bureau."""
    stats = {
        "transunion": {},
        "experian": {},
        "equifax": {}
    }
    
    summary_section = extract_section(text, "Summary", ["Account History", "Trade Lines"])
    if not summary_section:
        return stats
    
    # Pattern: Stat Name | TU Value | EX Value | EQ Value
    stat_patterns = {
        "total_accounts": r"Total\s*Accounts?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "open_accounts": r"Open\s*Accounts?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "closed_accounts": r"Closed\s*Accounts?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "delinquent": r"Delinquent\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "derogatory": r"Derogatory\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "collections": r"Collection[s]?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "balances": r"Balance[s]?\s*:?\s*\|?\s*\$?([\d,]+)\s*\|?\s*\$?([\d,]+)\s*\|?\s*\$?([\d,]+)",
        "payments": r"Payment[s]?\s*:?\s*\|?\s*\$?([\d,]+)\s*\|?\s*\$?([\d,]+)\s*\|?\s*\$?([\d,]+)",
        "public_records": r"Public\s*Records?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)",
        "inquiries": r"Inquir(?:y|ies)\s*(?:\(2\s*years?\))?\s*:?\s*\|?\s*(\d+)\s*\|?\s*(\d+)\s*\|?\s*(\d+)"
    }
    
    for stat_name, pattern in stat_patterns.items():
        match = re.search(pattern, summary_section, re.IGNORECASE)
        if match:
            tu_val = match.group(1).replace(",", "")
            ex_val = match.group(2).replace(",", "")
            eq_val = match.group(3).replace(",", "")
            
            stats["transunion"][stat_name] = int(tu_val) if tu_val.isdigit() else float(tu_val)
            stats["experian"][stat_name] = int(ex_val) if ex_val.isdigit() else float(ex_val)
            stats["equifax"][stat_name] = int(eq_val) if eq_val.isdigit() else float(eq_val)
    
    return stats


def extract_accounts_three_bureau(text: str) -> List[Dict[str, Any]]:
    """
    Extract account/tradeline information with per-bureau data.
    
    Each account has data from potentially all three bureaus.
    """
    accounts = []
    
    # Find Account History section
    account_section = extract_section(text, "Account History", ["Inquiries", "Public Information", "Creditor Contacts"])
    if not account_section:
        account_section = text
    
    # Split by creditor names (usually in ALL CAPS)
    # Common creditor patterns
    creditor_pattern = re.compile(
        r"^([A-Z][A-Z0-9\s/&.,'-]{2,40}(?:BANK|CREDIT|CARD|FINANCIAL|FCU|INC|USA|UNION)?)$",
        re.MULTILINE
    )
    
    # Find all creditor headers
    creditor_matches = list(creditor_pattern.finditer(account_section))
    
    for i, match in enumerate(creditor_matches):
        creditor_name = match.group(1).strip()
        
        # Skip if it's a section header
        skip_names = ["TRANSUNION", "EXPERIAN", "EQUIFAX", "ACCOUNT HISTORY", "TRADE LINES", "SUMMARY"]
        if any(skip in creditor_name.upper() for skip in skip_names):
            continue
        
        # Get the text block for this account (until next creditor)
        start_pos = match.end()
        end_pos = creditor_matches[i + 1].start() if i + 1 < len(creditor_matches) else len(account_section)
        account_block = account_section[start_pos:end_pos]
        
        # Parse the account block
        account = parse_account_block(creditor_name, account_block)
        if account:
            accounts.append(account)
    
    # Fallback: Try to find accounts using table patterns
    if len(accounts) < 3:
        accounts = extract_accounts_from_tables(account_section) or accounts
    
    return accounts


def parse_account_block(creditor_name: str, block: str) -> Optional[Dict[str, Any]]:
    """Parse a single account block with three-bureau data."""
    
    account = {
        "creditor_name": creditor_name,
        "account_number": None,
        "account_type": None,
        "account_type_detail": None,
        
        # TransUnion data
        "tu_status": None,
        "tu_balance": None,
        "tu_credit_limit": None,
        "tu_high_credit": None,
        "tu_payment": None,
        "tu_date_opened": None,
        "tu_payment_status": None,
        "tu_last_reported": None,
        "tu_past_due": None,
        "tu_bureau_code": None,
        
        # Experian data
        "ex_status": None,
        "ex_balance": None,
        "ex_credit_limit": None,
        "ex_high_credit": None,
        "ex_payment": None,
        "ex_date_opened": None,
        "ex_payment_status": None,
        "ex_last_reported": None,
        "ex_past_due": None,
        "ex_bureau_code": None,
        
        # Equifax data
        "eq_status": None,
        "eq_balance": None,
        "eq_credit_limit": None,
        "eq_high_credit": None,
        "eq_payment": None,
        "eq_date_opened": None,
        "eq_payment_status": None,
        "eq_last_reported": None,
        "eq_past_due": None,
        "eq_bureau_code": None,
        
        # Payment history (list of {month, year, tu_status, ex_status, eq_status})
        "payment_history": [],
        
        # Flags
        "has_discrepancy": False,
        "has_derogatory": False
    }
    
    # Account number (usually masked)
    acct_match = re.search(r"Account\s*#?\s*:?\s*([X\d*-]{4,20})", block, re.IGNORECASE)
    if acct_match:
        account["account_number"] = acct_match.group(1)
    
    # Account type
    type_match = re.search(r"Account\s*Type\s*:?\s*\|?\s*(\w+)", block, re.IGNORECASE)
    if type_match:
        account["account_type"] = type_match.group(1)
    
    # Parse three-column values
    # Pattern: Field | TU Value | EX Value | EQ Value
    
    field_patterns = {
        "status": (r"Account\s*Status\s*:?\s*\|?\s*(\w+)\s*\|?\s*(\w+)\s*\|?\s*(\w+)", "status"),
        "balance": (r"Balance\s*:?\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)", "balance"),
        "credit_limit": (r"Credit\s*Limit\s*:?\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)", "credit_limit"),
        "high_credit": (r"High\s*Credit\s*:?\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)", "high_credit"),
        "payment": (r"Monthly\s*Payment\s*:?\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)", "payment"),
        "date_opened": (r"Date\s*Opened\s*:?\s*\|?\s*(\d{1,2}/\d{1,2}/\d{2,4})\s*\|?\s*(\d{1,2}/\d{1,2}/\d{2,4})\s*\|?\s*(\d{1,2}/\d{1,2}/\d{2,4})", "date_opened"),
        "payment_status": (r"Payment\s*Status\s*:?\s*\|?\s*(.+?)\s*\|?\s*(.+?)\s*\|?\s*(.+?)(?:\n|$)", "payment_status"),
        "past_due": (r"Past\s*Due\s*:?\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)\s*\|?\s*\$?([\d,]+(?:\.\d{2})?)", "past_due"),
        "bureau_code": (r"Bureau\s*Code\s*:?\s*\|?\s*(.+?)\s*\|?\s*(.+?)\s*\|?\s*(.+?)(?:\n|$)", "bureau_code"),
    }
    
    for field_key, (pattern, field_name) in field_patterns.items():
        match = re.search(pattern, block, re.IGNORECASE)
        if match:
            tu_val = match.group(1).strip() if match.group(1) else None
            ex_val = match.group(2).strip() if match.group(2) else None
            eq_val = match.group(3).strip() if match.group(3) else None
            
            # Convert currency fields to float
            if field_name in ["balance", "credit_limit", "high_credit", "payment", "past_due"]:
                tu_val = parse_currency(tu_val)
                ex_val = parse_currency(ex_val)
                eq_val = parse_currency(eq_val)
            
            account[f"tu_{field_name}"] = tu_val
            account[f"ex_{field_name}"] = ex_val
            account[f"eq_{field_name}"] = eq_val
    
    # Parse payment history grid
    account["payment_history"] = parse_payment_history(block)
    
    # Detect derogatory
    derogatory_keywords = ["past due", "late", "collection", "charge off", "delinquent", "30 days", "60 days", "90 days"]
    for bureau in ["tu", "ex", "eq"]:
        status = account.get(f"{bureau}_payment_status", "") or ""
        if any(kw in status.lower() for kw in derogatory_keywords):
            account["has_derogatory"] = True
            break
    
    return account


def parse_payment_history(block: str) -> List[Dict[str, Any]]:
    """Parse the 24-month payment history grid."""
    history = []
    
    # Look for "Two-Year payment history" section
    history_match = re.search(r"Two-Year payment history(.+?)(?:$|[A-Z]{3,})", block, re.IGNORECASE | re.DOTALL)
    if not history_match:
        return history
    
    history_block = history_match.group(1)
    
    # Parse month/year headers
    # Format: Month | Oct Sep Aug Jul Jun May Apr Mar Feb Jan Dec Nov ...
    #         Year  | 25  25  25  25  25  25  25  25  25  25  24  24  ...
    month_row = re.search(r"Month\s*\|?\s*((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|\s)+)", history_block, re.IGNORECASE)
    year_row = re.search(r"Year\s*\|?\s*((?:\d{2}\s*)+)", history_block)
    
    if not month_row or not year_row:
        return history
    
    months = re.findall(r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)", month_row.group(1), re.IGNORECASE)
    years = re.findall(r"(\d{2})", year_row.group(1))
    
    # Parse status rows for each bureau
    tu_row = re.search(r"TransUnion\s*\|?\s*((?:OK|30|60|90|120|CO|\s)+)", history_block, re.IGNORECASE)
    ex_row = re.search(r"Experian\s*\|?\s*((?:OK|30|60|90|120|CO|\s)+)", history_block, re.IGNORECASE)
    eq_row = re.search(r"Equifax\s*\|?\s*((?:OK|30|60|90|120|CO|\s)+)", history_block, re.IGNORECASE)
    
    tu_statuses = re.findall(r"(OK|30|60|90|120|CO)", tu_row.group(1)) if tu_row else []
    ex_statuses = re.findall(r"(OK|30|60|90|120|CO)", ex_row.group(1)) if ex_row else []
    eq_statuses = re.findall(r"(OK|30|60|90|120|CO)", eq_row.group(1)) if eq_row else []
    
    # Combine into history list
    for i in range(min(len(months), len(years))):
        entry = {
            "month": months[i] if i < len(months) else None,
            "year": f"20{years[i]}" if i < len(years) else None,
            "tu_status": tu_statuses[i] if i < len(tu_statuses) else None,
            "ex_status": ex_statuses[i] if i < len(ex_statuses) else None,
            "eq_status": eq_statuses[i] if i < len(eq_statuses) else None
        }
        history.append(entry)
    
    return history


def extract_accounts_from_tables(text: str) -> List[Dict[str, Any]]:
    """Fallback: Extract accounts from table format in text."""
    accounts = []
    
    # Look for table rows with account data
    # Common pattern: Creditor | Account# | Balance | Status
    table_pattern = re.compile(
        r"([A-Z][A-Z0-9\s/&.,'-]+?)\s*\|\s*"
        r"([X\d*-]+)?\s*\|\s*"
        r"\$?([\d,]+(?:\.\d{2})?)?\s*\|\s*"
        r"(\w+)?",
        re.MULTILINE
    )
    
    for match in table_pattern.finditer(text):
        creditor = match.group(1).strip() if match.group(1) else None
        if creditor and len(creditor) >= 3:
            account = {
                "creditor_name": creditor,
                "account_number": match.group(2),
                "tu_balance": parse_currency(match.group(3)),
                "tu_status": match.group(4),
                "payment_history": [],
                "has_discrepancy": False,
                "has_derogatory": False
            }
            accounts.append(account)
    
    return accounts


def extract_inquiries_three_bureau(text: str) -> List[Dict[str, Any]]:
    """Extract inquiries from the report."""
    inquiries = []
    
    inquiry_section = extract_section(text, "Inquiries", ["Public Information", "Creditor Contacts"])
    if not inquiry_section:
        inquiry_section = extract_section(text, "Recent Inquiries", ["Public Information", "Creditor Contacts"])
    if not inquiry_section:
        return inquiries
    
    # Pattern: Company Name | Type | Date | Bureau
    inquiry_pattern = re.compile(
        r"([A-Z][A-Za-z0-9\s&.,'-]+?)\s*\|?\s*"
        r"(?:(\w+(?:\s+\w+)*)\s*\|?\s*)?"  # Type (optional)
        r"(\d{1,2}/\d{1,2}/\d{4})\s*\|?\s*"  # Date
        r"(TransUnion|Experian|Equifax)?",  # Bureau (optional)
        re.IGNORECASE
    )
    
    for match in inquiry_pattern.finditer(inquiry_section):
        company = match.group(1).strip() if match.group(1) else None
        if company and len(company) >= 3:
            inquiry = {
                "company": company,
                "type": match.group(2).strip() if match.group(2) else "Hard Inquiry",
                "date": match.group(3),
                "bureau": match.group(4) if match.group(4) else "Unknown"
            }
            inquiries.append(inquiry)
    
    return inquiries


def extract_public_records(text: str) -> List[Dict[str, Any]]:
    """Extract public records."""
    records = []
    
    public_section = extract_section(text, "Public Information", ["Creditor Contacts", "Inquiries"])
    if not public_section:
        return records
    
    # Check for "None Reported"
    if "none reported" in public_section.lower():
        return records
    
    # Parse any bankruptcy, judgment, lien records
    record_patterns = [
        (r"Bankruptcy.*?Chapter\s*(\d+).*?(\d{1,2}/\d{1,2}/\d{4})", "Bankruptcy"),
        (r"Judgment.*?\$?([\d,]+).*?(\d{1,2}/\d{1,2}/\d{4})", "Judgment"),
        (r"Tax\s*Lien.*?\$?([\d,]+).*?(\d{1,2}/\d{1,2}/\d{4})", "Tax Lien")
    ]
    
    for pattern, record_type in record_patterns:
        for match in re.finditer(pattern, public_section, re.IGNORECASE):
            records.append({
                "type": record_type,
                "details": match.group(1),
                "date": match.group(2) if match.lastindex >= 2 else None
            })
    
    return records


def extract_creditor_contacts(text: str) -> List[Dict[str, Any]]:
    """Extract creditor contact information."""
    contacts = []
    
    contact_section = extract_section(text, "Creditor Contacts", None)
    if not contact_section:
        return contacts
    
    # Pattern: Creditor Name, Address, Phone
    contact_pattern = re.compile(
        r"([A-Z][A-Z0-9\s/&.,'-]+?)\s+"
        r"([\dA-Z][A-Za-z0-9\s.,#-]+?(?:ST|AVE|BLVD|DR|RD|PO BOX)[A-Za-z0-9\s.,#-]+?[A-Z]{2}\s+\d{5}(?:-\d{4})?)\s+"
        r"(\d{10}|\d{3}[-.]?\d{3}[-.]?\d{4})",
        re.IGNORECASE | re.MULTILINE
    )
    
    for match in contact_pattern.finditer(contact_section):
        contacts.append({
            "creditor_name": match.group(1).strip(),
            "address": match.group(2).strip(),
            "phone": format_phone(match.group(3))
        })
    
    return contacts


# =============================================================================
# DISCREPANCY DETECTION
# =============================================================================

def detect_discrepancies(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Detect discrepancies between bureaus."""
    discrepancies = []
    
    # Check personal info discrepancies
    pi = result.get("personal_info", {})
    tu_name = pi.get("transunion", {}).get("name")
    ex_name = pi.get("experian", {}).get("name")
    eq_name = pi.get("equifax", {}).get("name")
    
    if tu_name and ex_name and eq_name:
        if tu_name != ex_name or ex_name != eq_name or tu_name != eq_name:
            discrepancies.append({
                "type": "personal_info",
                "field": "name",
                "description": f"Name varies across bureaus: TU='{tu_name}', EX='{ex_name}', EQ='{eq_name}'"
            })
    
    # Check summary stat discrepancies
    stats = result.get("summary_stats", {})
    tu_delinq = stats.get("transunion", {}).get("delinquent", 0)
    ex_delinq = stats.get("experian", {}).get("delinquent", 0)
    eq_delinq = stats.get("equifax", {}).get("delinquent", 0)
    
    if tu_delinq != ex_delinq or ex_delinq != eq_delinq:
        discrepancies.append({
            "type": "summary",
            "field": "delinquent_count",
            "description": f"Delinquent count varies: TU={tu_delinq}, EX={ex_delinq}, EQ={eq_delinq}"
        })
    
    # Check account discrepancies
    for account in result.get("accounts", []):
        # Balance discrepancy
        tu_bal = account.get("tu_balance")
        ex_bal = account.get("ex_balance")
        eq_bal = account.get("eq_balance")
        
        balances = [b for b in [tu_bal, ex_bal, eq_bal] if b is not None]
        if len(balances) >= 2 and len(set(balances)) > 1:
            discrepancies.append({
                "type": "account",
                "account": account.get("creditor_name"),
                "field": "balance",
                "description": f"Balance varies: TU=${tu_bal}, EX=${ex_bal}, EQ=${eq_bal}"
            })
        
        # Payment status discrepancy
        tu_status = account.get("tu_payment_status", "")
        ex_status = account.get("ex_payment_status", "")
        eq_status = account.get("eq_payment_status", "")
        
        statuses = [s for s in [tu_status, ex_status, eq_status] if s]
        if len(statuses) >= 2 and len(set(statuses)) > 1:
            discrepancies.append({
                "type": "account",
                "account": account.get("creditor_name"),
                "field": "payment_status",
                "description": f"Payment status varies: TU='{tu_status}', EX='{ex_status}', EQ='{eq_status}'"
            })
    
    return discrepancies


def detect_derogatory_accounts(accounts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Identify accounts with derogatory marks."""
    derogatory = []
    
    derogatory_keywords = [
        "past due", "late", "collection", "charge off", "charged off",
        "delinquent", "30 days", "60 days", "90 days", "120 days"
    ]
    
    for account in accounts:
        issues = []
        
        for bureau, prefix in [("TransUnion", "tu"), ("Experian", "ex"), ("Equifax", "eq")]:
            status = account.get(f"{prefix}_payment_status", "") or ""
            past_due = account.get(f"{prefix}_past_due", 0) or 0
            
            # Check payment status
            status_lower = status.lower()
            for keyword in derogatory_keywords:
                if keyword in status_lower:
                    issues.append({
                        "bureau": bureau,
                        "issue": f"Payment status: {status}"
                    })
                    break
            
            # Check past due amount
            if past_due > 0:
                issues.append({
                    "bureau": bureau,
                    "issue": f"Past due: ${past_due}"
                })
        
        if issues:
            derogatory.append({
                "creditor_name": account.get("creditor_name"),
                "account_number": account.get("account_number"),
                "issues": issues
            })
    
    return derogatory


# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def extract_section(text: str, start_marker: str, end_markers: Optional[List[str]]) -> Optional[str]:
    """Extract a section of text between markers."""
    start_idx = text.upper().find(start_marker.upper())
    if start_idx == -1:
        return None
    
    end_idx = len(text)
    if end_markers:
        for marker in end_markers:
            idx = text.upper().find(marker.upper(), start_idx + len(start_marker))
            if idx != -1 and idx < end_idx:
                end_idx = idx
    
    return text[start_idx:end_idx]


def parse_currency(value: Any) -> Optional[float]:
    """Parse a currency string to float."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    
    try:
        # Remove $ and commas
        cleaned = str(value).replace("$", "").replace(",", "").strip()
        if cleaned and cleaned != "N/A":
            return float(cleaned)
    except (ValueError, TypeError):
        pass
    
    return None


def clean_name(name: str) -> str:
    """Clean and format a name."""
    if not name:
        return ""
    # Remove extra whitespace
    name = " ".join(name.split())
    # Title case if all caps
    if name.isupper():
        name = name.title()
    return name


def format_phone(phone: str) -> str:
    """Format a phone number."""
    if not phone:
        return ""
    digits = re.sub(r"\D", "", phone)
    if len(digits) == 10:
        return f"({digits[:3]}) {digits[3:6]}-{digits[6:]}"
    return phone


def calculate_confidence(result: Dict[str, Any]) -> float:
    """Calculate parsing confidence score."""
    confidence = 0.0
    
    # Has scores
    scores = result.get("credit_scores", {})
    if any(scores.get(b, {}).get("score") for b in ["transunion", "experian", "equifax"]):
        confidence += 0.25
    
    # Has accounts
    if len(result.get("accounts", [])) > 0:
        confidence += 0.25
    if len(result.get("accounts", [])) >= 5:
        confidence += 0.15
    
    # Has personal info
    pi = result.get("personal_info", {})
    if any(pi.get(b, {}).get("name") for b in ["transunion", "experian", "equifax"]):
        confidence += 0.15
    
    # Has inquiries
    if len(result.get("inquiries", [])) > 0:
        confidence += 0.1
    
    # Has reference number and date
    if result.get("reference_number"):
        confidence += 0.05
    if result.get("report_date"):
        confidence += 0.05
    
    return min(confidence, 1.0)


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

def parse_credit_report_pdf(file_path: str) -> Dict[str, Any]:
    """
    Main entry point for parsing credit report PDFs.
    Automatically detects if it's a three-bureau report.
    """
    return parse_three_bureau_report(file_path)
